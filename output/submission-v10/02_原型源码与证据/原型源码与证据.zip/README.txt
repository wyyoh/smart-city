﻿数智选材 原型源码与证据

阅读顺序
作品说明：本次项目简表、说明书、商业计划书及50页作品论文。
runtime：可运行原型、企业数据、接口及冻结的计算和软件记录。
论文源稿：本次论文章节和文献表，便于文字复核与继续编辑。

启动原型
1. 进入runtime目录，阅读README.md中的环境与依赖说明。
2. 准备Python与Node.js环境，恢复冻结资源并安装依赖。
3. 在runtime目录执行：
powershell -ExecutionPolicy Bypass -File scripts/start-creative-demo.ps1
4. 按启动输出打开本地地址，进入“案例与设计”工作区。

资料定位
论文证据索引中的artifacts和docs路径，均从runtime目录查找。
五案采用企业工作簿的历史数值和构造要求，当前应用版本0.4.0。
原型与研究目录保留研发时的记录；本次申报文字以“作品说明”为阅读入口。
运行数据、案例与计算结果沿用冻结文件，顶层FILE-MANIFEST.json列出所有内容指纹。
