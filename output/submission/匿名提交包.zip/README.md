# 数智选材匿名提交版

本包提供项目简表与说明书、原型源代码、运行资源、五案证据和实际操作视频。
首先查看 output/submission/ 下两份PDF或DOCX。三类场景、五个构造案例，核心数值来自企业工作簿。

## 启动

准备 Python 3.12以上、Node.js 24、pnpm 11，在本目录的PowerShell运行：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/setup.ps1 -Python python
powershell -ExecutionPolicy Bypass -File scripts/start-creative-demo.ps1
```

打开 http://127.0.0.1:8766/?view=design 。已有依赖时也可先运行恢复脚本再启动。
安装依赖需要网络，核心操作在安装后本地运行。默认根路径保留历史成果入口。
按C1、C3、C2、C4、C5演示；细节见 docs/creative-demo-v7.md 。
视频位于 artifacts/submission-v8/demo/ ，为当前应用自动化操作的连续录屏，有字幕、无配音。
本包附MP4、字幕及操作记录；录屏原始WebM另存完整研发交接资料。

## 数据与匿名副本

材料数据库、当前前端和核心算法保持原样。工作簿查看副本为 data/材料数据查看.xlsx ，只移除Excel继承的绝对保存路径，所有工作表、数值、公式及其他包部件逐字节保持。软件使用冻结导入库及其原始数据身份；匿名版启动脚本不再次导入查看副本。
文本只替换账号、本机用户名、路径和主机名等元数据，并重算对应文件摘要；变化清单见 ANONYMIZATION.json 。
旧v0.2和v0.3发布ZIP不重复附带；当前源码、运行资源及历史证据文档均保留。原始研发证据另行完整保存。
模型预测为研究参考，新配方是未试验假设，当前不申报材料性能或实际行业收益提升。重新开展原始研究训练需使用完整研发资料，本包验证当前选材、比较、草案及已有研究资料查看。
第三方依赖与企业资料保留原来源；研发使用AI辅助，最终内容由参赛者复核。
简表身份栏按匿名评审要求留空。报名系统登记信息及实际上传要求由参赛者核对。
