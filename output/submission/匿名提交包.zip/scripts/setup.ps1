﻿param([string]$Python='python')
$ErrorActionPreference='Stop'
$ProjectRoot=Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $ProjectRoot
& $Python -c 'import sys; assert sys.version_info >= (3,12), "Python 3.12+ required"'
if($LASTEXITCODE -ne 0){throw 'Python 3.12 or later is required.'}
if(-not(Test-Path -LiteralPath '.venv\Scripts\python.exe')){
    & $Python -m venv .venv
    if($LASTEXITCODE -ne 0){throw 'venv creation failed.'}
}
if(Test-Path -LiteralPath 'artifacts\distribution\runtime-assets.json'){
    & .venv\Scripts\python.exe -X utf8 scripts/restore_published_assets.py
    if($LASTEXITCODE -ne 0){throw 'Published runtime asset restoration failed.'}
}
& .venv\Scripts\python.exe -m pip install -r requirements.lock.txt
if($LASTEXITCODE -ne 0){throw 'Python dependency installation failed.'}
pnpm --dir frontend install --frozen-lockfile
if($LASTEXITCODE -ne 0){throw 'Frontend dependency installation failed. Install Node.js 24 and pnpm 11 first.'}
pnpm --dir frontend build
if($LASTEXITCODE -ne 0){throw 'Frontend build failed.'}
$env:PYTHONPATH=Join-Path $ProjectRoot 'backend'
if(-not(Test-Path -LiteralPath (Join-Path $ProjectRoot 'data/workbench.sqlite'))){throw 'Restore the published database first.'}
Write-Host 'Anonymous demo uses the frozen imported database; viewing workbook is metadata-cleaned.'
if(-not(Test-Path -LiteralPath 'artifacts\models\DS.joblib') -or -not(Test-Path -LiteralPath 'artifacts\models\strain.joblib') -or -not(Test-Path -LiteralPath 'artifacts\models\TSR.joblib') -or -not(Test-Path -LiteralPath 'artifacts\models\residual.joblib')){
    & .venv\Scripts\python.exe -X utf8 -m app.ml.train
    if($LASTEXITCODE -ne 0){throw 'Model benchmark failed. Historical screening can still run.'}
}
Write-Host 'Setup complete. Run scripts/start-local.ps1. Training: python -m app.ml.train with PYTHONPATH=backend.'
